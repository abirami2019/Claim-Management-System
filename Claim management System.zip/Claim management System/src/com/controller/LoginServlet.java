package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.LoginClass;
import com.service.LoginService;
import com.service.LoginServiceImpl;


@WebServlet("/RegisterServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 LoginService logser=new LoginServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");   
		 String id=request.getParameter("id");
	     String name= request.getParameter("name");
	     LoginClass log=new LoginClass();
	     log.setId(id);
	     log.setName(name);
	     boolean res=logser.loginservice(log);
	     System.out.println("Result"+res);
	}

}
