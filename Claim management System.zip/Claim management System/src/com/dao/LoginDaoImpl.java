package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.login.LoginClass;
import com.util.DbConstants;
import com.util.DbUtil;

public class LoginDaoImpl implements LoginDao {

	@Override
	public boolean loginCheck(LoginClass log) {
		
		
			Connection con=null;
			PreparedStatement pst=null;
			boolean b=false;
			try {
				con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
				pst=con.prepareStatement("insert into login(id,name) values(?,?)");
				pst.setString(1, log.getId());
				pst.setString(2, log.getName());
				int r=pst.executeUpdate();
				System.out.println("Logindao"+r);
				if(r>0)
					b=true;
				else
					b=false;
				con.close();
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			return b;
		}
	

}
