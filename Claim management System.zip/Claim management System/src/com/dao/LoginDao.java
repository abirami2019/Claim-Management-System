package com.dao;

import com.login.LoginClass;

public interface LoginDao {
	
	public boolean loginCheck(LoginClass log);

}
