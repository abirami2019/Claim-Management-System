package com.service;

import com.dao.LoginDao;
import com.dao.LoginDaoImpl;
import com.login.LoginClass;

public class LoginServiceImpl implements LoginService {
	LoginDao dao=new LoginDaoImpl();
	@Override
	public boolean loginservice(LoginClass log) {
		boolean res=dao.loginCheck(log);
		System.out.println("service"+res);
		return res;
	}

}
