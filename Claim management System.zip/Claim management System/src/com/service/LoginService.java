package com.service;

import com.login.LoginClass;

public interface LoginService {
	public boolean loginservice(LoginClass log);

}
